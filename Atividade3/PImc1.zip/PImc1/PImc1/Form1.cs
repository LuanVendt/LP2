﻿using System;
using System.Windows.Forms;

namespace PImc1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            {
                double altura, peso, imc;
                string classificacao;
                imc = 0;


                if (double.TryParse(txtAltura.Text, out altura) &&
                   double.TryParse(txtPeso.Text, out peso))
                {

                    if (txtPeso.Text.Contains("."))
                    {
                        peso = peso / 10;

                    }

                    if (txtAltura.Text.Contains("."))
                    {

                        altura = altura * 10;
                    }


                    if (altura >= 100) altura = altura / 100;
                    double imcCalculo = peso / (altura * altura);
                    imc = Math.Round(imcCalculo, 2);

                }
                if (imc <= 18.5)
                {
                    classificacao = "Abaixo do Peso";
                }
                else if (imc >= 18.5 && imc < 24.9)
                {
                    classificacao = "Peso Ideal";
                }
                else if (imc >= 25.0 && imc < 29.9)
                {
                    classificacao = "Sobrepeso";
                }
                else if (imc >= 30.0 && imc < 39.9)
                {
                    classificacao = "Obesidade";
                }
                else
                {
                    classificacao = "Obesidade Grave";
                }

                MessageBox.Show(classificacao);
            }
        }


        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
