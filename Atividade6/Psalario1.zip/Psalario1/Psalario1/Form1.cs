﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNomeFuncionario_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSalarioBruto_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnVerificarDesconto_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;


            if (Double.TryParse(txtSalarioBruto.Text, out salarioBruto) && (double.TryParse(txtNumerodeFilhos.Text, out numeroFilhos)))
            {
                if (salarioBruto <= 0)
                {
                    MessageBox.Show("Salário precisa ser maior que zero");
                }
                else
                {
                    //Cálculo para INSS
                    if (salarioBruto <= 800.47)
                    {
                        txtAliquotaINSS.Text = "7,65%";
                        descontoINSS = 0.0765 * salarioBruto;
                    }
                    else if (salarioBruto <= 1050 && salarioBruto >= 800.48)
                    {
                        txtAliquotaINSS.Text = "8.655%";
                        descontoINSS = 0.08655 * salarioBruto;
                    }
                    else if (salarioBruto <= 1400.77 && salarioBruto >= 1050.01)
                    {
                        txtAliquotaINSS.Text = "9.0%";
                        descontoINSS = 0.09 * salarioBruto;
                        txtDescontoINSS.Text = descontoINSS.ToString("0.00");
                    }
                    else if (salarioBruto <= 2801.56 && salarioBruto >= 1400.78)
                    {
                        txtAliquotaINSS.Text = "11.0%";
                        descontoINSS = 0.11 * salarioBruto;
                        txtDescontoINSS.Text = descontoINSS.ToString("0.00");
                    }
                    else
                    {
                        txtAliquotaINSS.Text = "TETO";
                        descontoINSS = salarioBruto - 308.17;
                        txtDescontoINSS.Text = descontoINSS.ToString("0.00");
                    }

                    //Cálculo para IRPF
                    if (salarioBruto <= 1257.12)
                    {
                        txtAliquotaIRPF.Text = "0%";
                        descontoIRPF = 0;
                        txtDescontoIRPF.Text = descontoIRPF.ToString("0.00");
                    }
                    else if (salarioBruto > 1257.13 && salarioBruto <= 2512.08)
                    {
                        txtAliquotaIRPF.Text = "15.0%";
                        descontoIRPF = salarioBruto * 0.15;
                        txtDescontoIRPF.Text = descontoIRPF.ToString("0.00");
                    }
                    else
                    {
                        txtAliquotaIRPF.Text = "27.5%";
                        descontoIRPF = salarioBruto * 0.275;
                        txtDescontoIRPF.Text = descontoIRPF.ToString("0.00");
                    }

                    //Cálculo salário família
                    if (salarioBruto <= 435.52)
                    {
                        txtSalarioFamilia.Text = "22.33";
                        salarioFamilia = 22.33 * Convert.ToDouble(txtNumerodeFilhos.Text);
                        txtSalarioFamilia.Text = salarioFamilia.ToString("0.00");
                    }
                    else if (salarioBruto >= 453.53 && salarioBruto <= 654.61)
                    {
                        txtSalarioFamilia.Text = "15.74";
                        salarioFamilia = 15.74;
                        txtSalarioFamilia.Text = salarioFamilia.ToString("0.00");
                    }
                    else
                    {
                        txtSalarioFamilia.Text = "0";
                        salarioFamilia = 0;
                        txtSalarioFamilia.Text = salarioFamilia.ToString("0.00");
                    }

                    //Cálculo Salário Líquido
                    salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                    txtSalarioLiquido.Text = salarioLiquido.ToString("0.00");
                
                
                }
            }
            else
                MessageBox.Show("Salário Inválido");
        }

        private void txtAliquotaINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAliquotaIRPF_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSalarioFamilia_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDescontoIRPF_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
