﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo___Ativi_4
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;
        
        public Form1()
            
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtLado1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLado2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLado3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtLado1.Text, out lado1) &&
                Double.TryParse(txtLado2.Text, out lado2) &&
                Double.TryParse(txtLado3.Text, out lado3))
            {
                // double lado2Mlado3, lado1Mlado3, lado1Mlado2;

                /* lado2Mlado3 = lado2 - lado3;
                     lado1Mlado3 = lado1 - lado3;
                     lado1Mlado2 = lado1 - lado2;
                */
                if (lado1 > 0 &&
                        lado2 > 0 &&
                        lado3 > 0)
                {

                    if (lado1 == lado2 &&
                    lado1 == lado3)
                    {
                        //ado2Mlado3 = lado2Mlado3 * -1;
                        MessageBox.Show("Triângulo Equilátero");
                    }

                    if (lado1 == lado2 ||
                        lado1 == lado3 ||
                        lado2 == lado3)
                    {
                        //  lado1Mlado3 = lado1Mlado3 * -1;
                        MessageBox.Show("Triângulo Isósceles");
                    }

                    if (lado1 != lado2 &&
                        lado1 != lado3 &&
                        lado2 != lado3)
                    {
                        //   lado1Mlado2 = lado1Mlado2 * -1;
                        MessageBox.Show("Triângulo Escaleno");
                    }


                }
                else
                    MessageBox.Show("Valores Precisam ser maiores que Zero");
                

            }
            else
                MessageBox.Show("Valores Inválidos");
            
            

            /* if (lado1 > 0 &&
                     lado2 > 0 &&
                     lado3 > 0)
                {

                    if (lado2Mlado3 < lado1 && lado1 < (lado2 + lado3))
                    {
                        MessageBox.Show("Triângulo Isósceles");
                    }

                    if (lado1Mlado3 < lado2 && lado2 < (lado1 + lado3))
                    {
                        MessageBox.Show("Triângulo Equilátero");
                    }

                    if (lado1Mlado2 < lado3 && lado3 < (lado1 + lado2))
                    {
                        MessageBox.Show("Triângulo Escaleno");
                    }

                    else
                        MessageBox.Show("Valores Precisam ser Maiores que zero");
                }


                else
                    MessageBox.Show("Valores Inválidos");
            }
        */  }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();

            txtLado1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
