﻿namespace Pmatrizes
{
    partial class Matrizes
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverte = new System.Windows.Forms.Button();
            this.btnQtdePreco = new System.Windows.Forms.Button();
            this.btnVariavelTotal = new System.Windows.Forms.Button();
            this.btnMediaAlunos = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnNome = new System.Windows.Forms.Button();
            this.lbxNomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnInverte
            // 
            this.btnInverte.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnInverte.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverte.Location = new System.Drawing.Point(47, 76);
            this.btnInverte.Name = "btnInverte";
            this.btnInverte.Size = new System.Drawing.Size(113, 94);
            this.btnInverte.TabIndex = 0;
            this.btnInverte.Text = "Ler 20 Números e Inverter";
            this.btnInverte.UseVisualStyleBackColor = false;
            this.btnInverte.Click += new System.EventHandler(this.btnEx1_Click);
            // 
            // btnQtdePreco
            // 
            this.btnQtdePreco.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnQtdePreco.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdePreco.Location = new System.Drawing.Point(209, 76);
            this.btnQtdePreco.Name = "btnQtdePreco";
            this.btnQtdePreco.Size = new System.Drawing.Size(113, 94);
            this.btnQtdePreco.TabIndex = 1;
            this.btnQtdePreco.Text = "Ler Qtde e Preço Mercadorias";
            this.btnQtdePreco.UseVisualStyleBackColor = false;
            this.btnQtdePreco.Click += new System.EventHandler(this.btnEx2_Click);
            // 
            // btnVariavelTotal
            // 
            this.btnVariavelTotal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnVariavelTotal.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVariavelTotal.Location = new System.Drawing.Point(365, 76);
            this.btnVariavelTotal.Name = "btnVariavelTotal";
            this.btnVariavelTotal.Size = new System.Drawing.Size(113, 94);
            this.btnVariavelTotal.TabIndex = 2;
            this.btnVariavelTotal.Text = "Variável Total";
            this.btnVariavelTotal.UseVisualStyleBackColor = false;
            this.btnVariavelTotal.Click += new System.EventHandler(this.btnEx3_Click);
            // 
            // btnMediaAlunos
            // 
            this.btnMediaAlunos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnMediaAlunos.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMediaAlunos.Location = new System.Drawing.Point(209, 197);
            this.btnMediaAlunos.Name = "btnMediaAlunos";
            this.btnMediaAlunos.Size = new System.Drawing.Size(113, 94);
            this.btnMediaAlunos.TabIndex = 3;
            this.btnMediaAlunos.Text = "Média Alunos";
            this.btnMediaAlunos.UseVisualStyleBackColor = false;
            this.btnMediaAlunos.Click += new System.EventHandler(this.btnEx5_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnArrayList.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrayList.Location = new System.Drawing.Point(47, 197);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(113, 94);
            this.btnArrayList.TabIndex = 4;
            this.btnArrayList.Text = "ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = false;
            this.btnArrayList.Click += new System.EventHandler(this.btnEx4_Click);
            // 
            // btnNome
            // 
            this.btnNome.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNome.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNome.Location = new System.Drawing.Point(365, 197);
            this.btnNome.Name = "btnNome";
            this.btnNome.Size = new System.Drawing.Size(113, 94);
            this.btnNome.TabIndex = 5;
            this.btnNome.Text = "Nome Pessoas";
            this.btnNome.UseVisualStyleBackColor = false;
            this.btnNome.Click += new System.EventHandler(this.btnEx6_Click);
            // 
            // lbxNomes
            // 
            this.lbxNomes.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxNomes.FormattingEnabled = true;
            this.lbxNomes.ItemHeight = 23;
            this.lbxNomes.Location = new System.Drawing.Point(508, 76);
            this.lbxNomes.Name = "lbxNomes";
            this.lbxNomes.Size = new System.Drawing.Size(231, 211);
            this.lbxNomes.TabIndex = 7;
            this.lbxNomes.Visible = false;
            this.lbxNomes.SelectedIndexChanged += new System.EventHandler(this.lbxNomes_SelectedIndexChanged);
            // 
            // Matrizes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(838, 383);
            this.Controls.Add(this.lbxNomes);
            this.Controls.Add(this.btnNome);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnMediaAlunos);
            this.Controls.Add(this.btnVariavelTotal);
            this.Controls.Add(this.btnQtdePreco);
            this.Controls.Add(this.btnInverte);
            this.Name = "Matrizes";
            this.Text = "Matrizes";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInverte;
        private System.Windows.Forms.Button btnQtdePreco;
        private System.Windows.Forms.Button btnVariavelTotal;
        private System.Windows.Forms.Button btnMediaAlunos;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnNome;
        private System.Windows.Forms.ListBox lbxNomes;
    }
}

