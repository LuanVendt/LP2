﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[90, 2];
            double mediaFilme1 = 0;
            double mediaFilme2 = 0;
            string auxiliar; 
            string auxiliar2;

            for (var i = 0; i < 90; i++)
            {
                for (var j = 0; j < 2; j++)
              {

                    auxiliar = Interaction.InputBox("Pessoa " + (i + 1) + " Nota Filme 1: " + (j + 1));
            //        auxiliar2 = Interaction.InputBox("Pessoa " + (i + 1) + " Nota Filme 2: " + (j + 1));
               
                    if (!Double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;

                    }
                    
                    if (!Double.TryParse(auxiliar2, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;

                    }
                
                    else
                    {
                        if (!(notas[i, j] >= 0 && notas[i, j] <= 10))
                        {
                            MessageBox.Show("Nota inválida!");
                            j--;
                        }
                    
                        else
                        {
                           while (notas[i,0] >= 0)
                            {
                                mediaFilme1 = notas[i, 0] + mediaFilme1;
                            }
                            mediaFilme1 = mediaFilme1 / 90;

                            while (notas[i,1] >= 0)
                            {
                                mediaFilme2 = notas[i, 1] + mediaFilme2;

                                mediaFilme2 = mediaFilme2 / 90;

                                lbxFilme.Visible = true;
                                lbxFilme.Items.Clear();

                                auxiliar = "Pessoa " + (i + 1) + "Nota Filme 1: " + notas[i, 0] + "\n";
                                auxiliar2 = "Pessoa " + (i + 0) + "Nota Filme 2: " + notas[i, 1] + "\n";
                                lbxFilme.Items.Add(auxiliar);
                                lbxFilme.Items.Add(auxiliar2);
                            }
                        }

                        lbxFilme.Items.Add(mediaFilme1.ToString("N2"));
                        lbxFilme.Items.Add(mediaFilme2.ToString("N2"));

                            

                        }

                    }
            }
                    
                }
            }
 }
} 
    

